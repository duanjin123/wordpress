<?php
foreach ($args as $key => $value) {
	$response[$key]	= $value;
}