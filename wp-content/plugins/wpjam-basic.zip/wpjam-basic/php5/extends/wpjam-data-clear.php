<?php
/*
Plugin Name: 数据清理
Plugin URI: http://wpjam.net/item/wpjam-basic/
Description: 清理 WordPress 冗余数据
Version: 1.0
*/