<?php
/*
Plugin Name: Rewrite 规则优化
Plugin URI: http://wpjam.net/item/wpjam-basic/
Description: 优化相关功能的的 Rewrite 规则以提高网站效率！
Version: 1.0
*/