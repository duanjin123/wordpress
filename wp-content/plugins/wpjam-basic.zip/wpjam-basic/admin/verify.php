<?php

include(WPJAM_BASIC_PLUGIN_DIR.'admin/includes/class-wpjam-verify.php');